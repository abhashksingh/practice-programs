#include <iostream>
#include <vector>
#include <algorithm>
#include <limits.h>
#include <stdio.h>
#include <iomanip>

using namespace std;

void printConfiguration(long long r, long long c,long long mines);//2d mines
void printSpecial2d(long long r, long long c,long long mines);
//void printConfiguration(long long* arr,long long r, long long c,long long mines);//1d mines

int main()
{
	long long t,i=0;
	cin>>t;
	for(i=1;i<=t;i++)
	{
		long long R,C,M,safe;
		cin>>R>>C>>M;
		if(R==1||C==1)
		{
			safe = (R*C)-1;
			if(M>safe)
			{
				cout<<"Case #"<<i<<": "<<endl<<"Impossible"<<endl;
			}
			else
			{
				if(R==1&&C==1){cout<<"Case #"<<i<<": "<<endl<<'c'<<endl;}
				else
				{
					cout<<"Case #"<<i<<": "<<endl;
					printConfiguration(R,C,M);
				}
			}
		}
		else
		{
			safe = (R*C)-4;
			if(M>safe)
			{
				if(M!=((R*C)-1))
				{
					cout<<"Case #"<<i<<": "<<endl<<"Impossible"<<endl;
				}
				else
				{
					cout<<"Case #"<<i<<": "<<endl;
					printSpecial2d(R,C,M);
					//cout<<endl;
				}
			}
			else
			{
				cout<<"Case #"<<i<<": "<<endl;
				printConfiguration(R,C,M);
			}
		}
	}
}

void printConfiguration(long long r, long long c,long long mines)
{
	long long i=0,j=0;
	if(r==1||c==1)
	{
		long long len;
		if(c==1 && r!=1)
		{
			len = r;
		}
		else if (r==1 && c!=1)
		{
			len = c;
		}
		char* arr = new char[len];
		for(i=0;i<len;i++)
		{
			if(i==0)
			{arr[i]='c';}
			else if(i<(len-mines))
			{arr[i]='.';}
			else
			{arr[i]='*';}
		}
		for(long long i=0;i<len;i++)
		{
			cout<<arr[i];
			if(c==1)
			cout<<endl;
		}
		if(r==1)
		cout<<endl;
	}
	else
	{
		char** arr = new char*[r];
		for(i=0;i<r;i++)
		{arr[i]= new char[c];}
		for(i=0;i<r;i++)
		{
			for(j=0;j<c;j++)
			{
				arr[i][j]='*';
			}
		}
		arr[0][0]='c';
		arr[0][1]='.';
		arr[1][0]='.';
		arr[1][1]='.';
		long long safe = (r*c) - 4-mines;
		for(i=0;i<r;i++)
		{
			for(j=0;j<c;j++)
			{
				
					if(arr[i][j]=='*')
					{
						if(safe > 0)
						{
							arr[i][j]='.';
							safe--;
						}
					}
					else
					{continue;}
				
			}
		}
		for(i=0;i<r;i++)
		{
			for(j=0;j<c;j++)
			{cout<<arr[i][j];}
			cout<<endl;
		}
	}
}


void printSpecial2d(long long r, long long c,long long mines)
{
	//char** arr = new char*[r];
	long long i=0,j=0;
	for(i=0;i<r;i++)
	{
		for(j=0;j<c;j++)
		{
			if(i==0 && j==0)
			{
				cout<<'c';
			}
			else
			{cout<<'*';}
		}
		cout<<endl;
	}
}
